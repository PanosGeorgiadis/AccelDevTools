// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

#include <exception>
#include <string>

namespace cpp
{
namespace exceptions
{

class not_implemented final:
    public std::runtime_error
{
public:
    not_implemented(const std::string& msg) : runtime_error(msg.c_str())
    {
    }
};

}
}
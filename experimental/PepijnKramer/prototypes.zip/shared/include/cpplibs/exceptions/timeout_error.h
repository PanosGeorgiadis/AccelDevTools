// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

#include <exception>
#include <string>

namespace cpp
{
namespace exceptions
{

class timeout_error final:
    public std::runtime_error
{
public:
    timeout_exception(const std::string& msg) : runtime_error(msg.c_str())
    {
    }
};

}
}
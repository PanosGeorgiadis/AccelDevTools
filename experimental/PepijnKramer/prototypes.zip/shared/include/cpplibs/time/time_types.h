// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

#include <chrono>

typedef std::chrono::system_clock systemclock_t;
typedef systemclock_t::duration duration_t;
typedef systemclock_t::time_point timepoint_t;


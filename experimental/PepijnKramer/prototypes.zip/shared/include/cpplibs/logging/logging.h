#pragma once
/*
#include <memory>
#include <type_traits>
#include <string>
#include <iostream>
#include <Fei/enum_cast.h>

namespace cpp
{
namespace logging
{

template<typename E>
struct enable_bitmask_operators
{
	static constexpr bool enable = false;
};

template<typename E>
typename std::enable_if<enable_bitmask_operators<E>::enable, E>::type
operator|(E lhs, E rhs)
{
	typedef typename std::underlying_type<E>::type underlying;
	return static_cast<E>(
		static_cast<underlying>(lhs) | static_cast<underlying>(rhs));
}

enum class Category
{
	Debug = 0x001,


};

template<> struct enable_bitmask_operators<Category>
{
	static constexpr bool enable = true;
};

enum class Severity
{
	Informational,
	Warning,
	Error,
	Fatal
};

//---------------------------------------------------------------------------------------------------------------------

class Logging_itf
{
public:
	Logging_itf(const Logging_itf&) = delete;
	Logging_itf& operator=(const Logging_itf&) = delete;

	virtual void log(const std::wstring& message) const = 0;
	virtual void log(const Severity severity, const  Category category,const std::wstring& message ) const = 0;

protected:
	Logging_itf() = default;
	virtual ~Logging_itf() = default;
};

//---------------------------------------------------------------------------------------------------------------------

namespace details
{
template <class Elem, class Tr = std::char_traits<Elem>, class Alloc = std::allocator<Elem> >
class basic_buf : public std::basic_streambuf<Elem, Tr>
{
	using int_type = typename std::basic_streambuf<Elem, Tr>::int_type;
	using traits_type = typename std::basic_streambuf<Elem, Tr>::traits_type;

public:
	basic_buf(std::basic_ostream<Elem, Tr>& output_stream) :
		m_output_stream(output_stream)
	{
	}

protected:
	int sync()
	{
		m_buf[m_index] = 0;
		m_index = 0;
		m_output_stream << m_buf;
		return 0;
	}

	int_type overflow(int_type c)
	{
		if (c == traits_type::eof())
			return 0;

		m_buf[m_index] = traits_type::to_char_type(c);
		m_index++;

		if (c == '\n' || m_index == m_bufferSize - 1)
		{
			sync();
		}
		return c;
	}

private:
	static const size_t m_bufferSize = 256;
	std::basic_ostream<Elem, Tr>& m_output_stream;
	__declspec(thread) static Elem m_buf[m_bufferSize];
	__declspec(thread) static size_t m_index;
};

template <class Elem, class Tr, class Alloc>
Elem basic_buf<Elem, Tr, Alloc>::m_buf[m_bufferSize] = { '\0' };

template <class Elem, class Tr, class Alloc>
size_t basic_buf<Elem, Tr, Alloc>::m_index = 0u;

} // details

class Log final :
	public std::wostream
{
public:
	explicit Log(Logging_itf& itf) :
		std::wostream(&m_buffer),
		m_logitf(itf),
		m_category(Category::Debug),
		m_severity(Severity::Informational),
		m_log_with_flags(false)
	{
	}

	Log(Logging_itf& itf, Severity sev, Category cat) :
		std::wostream(&m_buffer),
		m_logitf(itf),
		m_category(cat),
		m_severity(sev),
		m_log_with_flags(true),
		m_stream_ptr(std::make_shared<std::wostringstream>())
	{
	}
	
	virtual ~Log()
	{
		m_buffer.pubsync();
		(m_log_with_flags) ? m_logitf.log(m_severity, m_category, m_stream_ptr->str()) : m_logitf.log(m_stream_ptr->str());
	}

private:
	Logging_itf& m_logitf;
	Severity m_severity;
	Category m_category;
	bool m_log_with_flags;

	std::shared_ptr<std::wostringstream> m_stream_ptr;
	details::basic_buf<wchar_t> m_buffer;

};


//
//class Logger final
//{
//public:
//	explicit Logger(Logging_itf& log_itf) :
//		m_log_itf(log_itf)
//	{
//	}
//
//	details::LogEntry log()
//	{
//		return details::LogEntry(m_log_itf);
//	}
//
//	details::LogEntry log(Severity sev, Category cat)
//	{
//		return details::LogEntry(m_log_itf, sev, cat);
//	}
//
//private:
//	Logging_itf& m_log_itf;
//
//};

//---------------------------------------------------------------------------------------------------------------------

class StdOutputLog :
	public Logging_itf
{
public:
	StdOutputLog()
	{
	}

	virtual ~StdOutputLog()
	{
	}

	virtual void log(const std::wstring& message) const override
	{
		std::wcout << message;
	}

	virtual void log(const Severity severity, const Category category, const std::wstring& message) const override
	{

		std::wcout << message;
	}
};

//---------------------------------------------------------------------------------------------------------------------

//class TerminalLog :
//	public Logging_itf
//{
//}

//---------------------------------------------------------------------------------------------------------------------


}
}*/
#ifndef CPP_STATIC_ASSERTS_H
#define CPP_STATIC_ASSERTS_H

namespace cpp
{
	namespace static_asserts
	{
		// for_all, to be used to check variadic template arguments in 
		// static asserts
		// example:
		//  
		// static_assert(for_all<std::is_same<T, Args>::value...>::value, "at least one argument not of type T");
		//
		template <bool... all> struct for_all
		{
		};

		template <bool... tail>
		struct for_all<true, tail...> : for_all < tail... >
		{
		};

		template <bool... tail>
		struct for_all<false, tail...> : std::false_type
		{
		};

		template <> struct
			for_all<> : std::true_type
		{
		};
	}
}

#endif
// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

// Workaround atl include bug
struct IUnknown;
#include <type_traits>
#include <boost/signals2.hpp>
#include <cpplibs/concurrency/dispatcher2.h>
#include "event_connection_itf.h"

namespace cpp
{
namespace events
{

template<typename Fn>
class SignalConnection final: 
    public EventConnectionItf
{

typedef boost::signals2::signal<Fn> SignalType;


public:
    SignalConnection() = delete;
    SignalConnection(const SignalConnection&) = delete;
    SignalConnection& operator=(const SignalConnection&) = delete;
    
    
    explicit SignalConnection(const cpp::concurrency::Dispatcher2& dispatcher) :
        m_dispatcher(dispatcher)
    {
    }

    ~SignalConnection()
    {
        disconnect();
    }

    EventConnectionItf& connect(const std::function<Fn>& fn)
    {
        m_connection = m_dispatcher.Invoke([this,fn]
        {
            return m_signal.connect(fn);
        });

        return *this;
    }

    void signal() const
    {
        m_signal();
    }

    template<typename Arg>
    void signal(const Arg& a)
    {
        m_signal(a);
    }

    virtual void disconnect() override
    {
        m_dispatcher.Invoke([this]
        {
            m_connection.disconnect();
        });
    }
           
private:
    const cpp::concurrency::Dispatcher2& m_dispatcher;
    SignalType m_signal;
    boost::signals2::connection m_connection;
};

}
}
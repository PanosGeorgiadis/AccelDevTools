// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific
#pragma once

namespace cpp
{
namespace events
{

class EventConnectionItf
{
public:
    EventConnectionItf(const EventConnectionItf&) = delete;
    EventConnectionItf& operator=(const EventConnectionItf&) = delete;

    virtual void disconnect() = 0;

protected:
    EventConnectionItf() = default;
    virtual ~EventConnectionItf() = default;
};

}
}

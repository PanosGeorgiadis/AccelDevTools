#pragma once
#pragma comment(lib,"cpplibs.lib")

// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of ThermoFisher Scientific

#ifndef CPP_STATE_VARIABLE
#define CPP_STATE_VARIABLE

#include <array>
#include <condition_variable>
#include <mutex>
#include <cpplibs/asserts/static_asserts.h>
#include <cpplibs/time/time_types.h>

namespace cpp
{
namespace concurrency
{
	template<typename T>
	class state_variable final
	{
	public:
		state_variable() = delete;
		state_variable(const state_variable&) = delete;
		state_variable operator=(const state_variable&) = delete;

		explicit state_variable(const T& value) :
			m_value(value)
		{
		}

		virtual ~state_variable()
		{
		}

		void set(const T& value)
		{
			{
				std::unique_lock<std::mutex> lock(m_value_mutex);
				m_value = value;
			}
			m_value_changed.notify_all();
		}

		T get() const
		{
			std::unique_lock<std::mutex> lock(m_value_mutex);
			return m_value;
		}

		void operator=(const T& value)
		{
			set(value);
		}

		bool operator==(const T& value)
		{
			std::unique_lock<std::mutex> lock(m_value_mutex);
			return (m_value == value);
		}

		bool operator!=(const T& value)
		{
			return !operator==(value);
		}

		operator T() const
		{
			return get();
		}

		void wait_for(const T& value)
		{
			std::unique_lock<std::mutex> lock(m_value_mutex);
			m_value_changed.wait(lock, [this, value]()
			{
				return m_value == value;
			});
		}

		bool try_wait_for(const T& value, const timepoint_t& end_time)
		{
			std::unique_lock<std::mutex> lock(m_value_mutex);

			auto now = systemclock_t::now();
			
			if (now > end_time)
			{
				return m_value == value;
			}

			auto duration = end_time - now;

			return m_value_changed.wait_for(lock, duration, [this, value]()
			{
				return m_value == value;
			});
		}

		bool try_wait_for(const T& value, const duration_t& duration)
		{
			auto t = systemclock_t::now() + duration;
			return try_wait_for(value,t);
		}

		void wait_for(const T& value, const timepoint_t& end_time)
		{
			if (!try_wait_for(value, end_time))
			{
				throw exceptions::timeout_exception();
			}
		}

		template<typename... Args>
		T wait_any(Args... args)
		{
			static_assert(static_asserts::for_all<std::is_same<T, Args>::value...>::value, "at least one argument not of type T");
			std::array<T, sizeof...(args)> states = { args... };

			std::unique_lock<std::mutex> lock(m_value_mutex);

			m_value_changed.wait(lock, [this, states]()
			{
				for (unsigned int i = 0; i < states.size(); ++i)
				{
					if (m_value == states[i])
						return true;
				}
				return false;
			});

			return m_value;
		}
		
		template<typename... Args>
		T wait_any(Args... args, const std::chrono::milliseconds& duration)
		{
			static_assert(static_asserts::for_all<std::is_same<T, Args>::value...>::value, "at least one argument not of type T");
			std::array<T, sizeof...(args)> states = { args... };

			std::unique_lock<std::mutex> lock(m_value_mutex);

			return m_value_changed.wait_for(lock, duration, [this, states]()
			{
				for (unsigned int i = 0; i < states.size(); ++i)
				{
					if (m_value == states[i])
						return true;
				}
				return false;
			});

			return m_value;
		}

	private:
		mutable std::mutex m_value_mutex;
		std::condition_variable m_value_changed;
		T m_value;
	};
}
}

#endif /* CPP_STATE_VARIABLE */
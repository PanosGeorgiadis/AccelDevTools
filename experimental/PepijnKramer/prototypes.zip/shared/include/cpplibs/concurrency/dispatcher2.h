// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

#include <exception>

// Workaround atl include bug
struct IUnknown;
#include <Fei/Dispatcher.h>

namespace cpp
{
namespace concurrency
{

//---------------------------------------------------------------------------------------------------------------------

class not_dispatcher_thread_exception :
    public std::runtime_error
{
public:
    explicit not_dispatcher_thread_exception(const std::string& msg) :
        std::runtime_error(msg)
    {
    }
};

//---------------------------------------------------------------------------------------------------------------------

class is_dispatcher_thread_exception :
    public std::runtime_error
{
public:
    explicit is_dispatcher_thread_exception(const std::string& msg) :
        std::runtime_error(msg)
    {
    }
};

//---------------------------------------------------------------------------------------------------------------------
//
// TODO : 
// - add debug information to Call/Notify
//          - allow passing and storage of name of calling __FUNCTION__ in task
//          - allow storage of calling thread id
// - add perfomance counter to dispatcher to check responsiveness, number of calls handled
// in debug build add run_every(10 ms) increase counter and every (1s) the number of run_every(10ms) handled.
// define a required response time for dispatcher and log whenever this is not met (including name of calling function)
//
// ALL this should NOT be present in release builds!
//

class Dispatcher2 :
    public Fei::Dispatcher
{
public:
    Dispatcher2() :
        Fei::Dispatcher()
    {
    }

    Dispatcher2(const std::string& name) :
        Fei::Dispatcher(name)
    {
    }

    virtual ~Dispatcher2()
    {
    }

    void CheckIsDispatcherThread(const std::string& msg) const
    {
        if (!IsDispatcherThread())
        {
            auto output = msg + " not called on expected dispatcher thread";
            throw not_dispatcher_thread_exception(output);
        }
    }

    void CheckIsNotDispatcherThread(const std::string& msg) const
    {
        if (!IsDispatcherThread())
        {
            auto output = msg + " not called on expected dispatcher thread";
            throw is_dispatcher_thread_exception(output);
        }
    }

    template <typename Fn>
    auto Invoke(const Fn& fn) const -> decltype(fn())
    {
        if (IsDispatcherThread())
        {
            return fn();
        }

        return Call(fn);
    }
};
}
}

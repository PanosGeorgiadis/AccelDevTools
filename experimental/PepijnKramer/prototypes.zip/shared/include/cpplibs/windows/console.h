// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

#include <cstdint>
#include <iostream>
#include <map>
#include <string>

namespace cpp
{
namespace windows
{

enum class colors
{
    reset,
    normal,
    black,
    darkGray,
    blue,
    lightBlue,
    green,
    lightGreen,
    cyan,
    lightCyan,
    red,
    lightRed,
    purple,
    lightPurple,
    brown,
    yellow,
    lightGray,
    white
};

class Console final
{
public:
    Console();
    ~Console() = default;
    Console(const Console&) = delete;
    Console& operator=(const Console&) = delete;

    static const std::wstring box()
    {
        return L"[  log >>  ] ";
    }

    void set_color(const colors& color);
    void store_color();
    void reset_color();

    void out(const colors& color, const std::wstring& output);

private:
    std::uint16_t get_attributes() const;

    void* m_console;
    std::uint16_t m_attributes;
    std::map<colors, std::wstring> m_scolormap;
    std::map<colors, unsigned int> m_icolormap;
};

}
}
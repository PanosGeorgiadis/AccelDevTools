// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of ThermoFisher Scientific

#pragma once
#pragma comment(lib,"cpplibs.lib")

#include <stdexcept>
#include <string>
#include <wtypes.h>

namespace cpp
{
namespace windows
{

//-----------------------------------------------------------------------------------------------------------------
//
// exception class to be thrown when a Win32 api call fails.
//

class winapi_error final : 
    public std::runtime_error
{
public:
    winapi_error() = delete;
    virtual ~winapi_error() = default;
    explicit winapi_error(const std::string& message);
};

//-----------------------------------------------------------------------------------------------------------------
//
// class checked_winapi_error
// 
// responsibility:
//   convert win32 errors into C++ exceptions 
//
// use : 
//      checked_winapi_error error = ::WinApiCall();

class checked_winapi_error
{
public:
    checked_winapi_error() = delete;
    virtual ~checked_winapi_error() = default;
    checked_winapi_error(const checked_winapi_error&) = delete;
    checked_winapi_error& operator=(const checked_winapi_error&) = delete;
    checked_winapi_error(BOOL retval);  //TICS !INT#001 implicit by design to be able to write one-liner checks!
    void operator=(const BOOL retval);

    static void throw_error();

private:
    void check(BOOL retval);
    std::string format_message() const noexcept;
};

}
}
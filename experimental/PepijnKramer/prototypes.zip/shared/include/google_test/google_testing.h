// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

//TICS -* workaround google test warnings
#pragma warning(push)
#pragma warning(disable:4996) // ::tr1 deprecated
#pragma comment(lib,"gtest.lib")
#include <gtest/gtest.h>
#pragma warning(pop)
//TICS +*


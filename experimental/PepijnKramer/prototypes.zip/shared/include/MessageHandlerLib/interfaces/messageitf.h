// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

#include <cstdint>
#include <cpplibs/time/time_types.h>
#include <MessageHandlerLib/interfaces/MessageTypes.h>

namespace MessageHandlerLib {

class MessageItf
{
public:
    MessageItf(const MessageItf&) = delete;
    MessageItf& operator=(const MessageItf&) = delete;
    virtual ~MessageItf() = default;

    virtual const std::uint32_t get_id() const = 0;
    virtual const MessageType& get_type() const = 0;
    virtual const std::wstring& get_text() const = 0;
    virtual const std::wstring& get_subsystem_name() const = 0;
    virtual const timepoint_t& get_timeout_time() const = 0;


protected:
    MessageItf() = default;

};

} // namespace MessageHandlerLib
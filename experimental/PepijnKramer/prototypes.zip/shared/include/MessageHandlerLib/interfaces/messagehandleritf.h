// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

#include <functional>
#include <memory>
#include <cpplibs/events/event_connection_itf.h>
#include <cpplibs/time/time_types.h>
#include "MessageHandlerLib/interfaces/MessageItf.h"

namespace MessageHandlerLib {

typedef void MessageEventHandler(const MessageItf&);

class MessageHandlerItf
{
public:
    MessageHandlerItf(const MessageHandlerItf&) = delete;
    MessageHandlerItf& operator=(const MessageHandlerItf&) = delete;
    

    virtual MessageItf& create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem) = 0;
    virtual MessageItf& create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem, const duration_t& timeout_duration) = 0;

    virtual const std::wstring& get_name() const = 0;
    virtual void start(const duration_t& loop_time) = 0;

    virtual cpp::events::EventConnectionItf& connect_on_message_added(const std::function<MessageEventHandler>& handler) = 0;
    virtual cpp::events::EventConnectionItf& connect_on_message_removed(const std::function<MessageEventHandler>& handler) = 0;

protected:
    MessageHandlerItf() = default;
    virtual ~MessageHandlerItf() = default;
};

} // namespace MessageHandlerLib
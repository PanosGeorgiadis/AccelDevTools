#pragma once


namespace cpplibs
{
namespace concurrency
{

class SignalConnectionItf
{
public:
    SignalConnectionItf(const SignalConnectionItf&) = delete;
    SignalConnectionItf& operatoer=(const SignalConnectionItf&) = delete;

    virtual void disconnect() 

protected:
    SignalConnectionItf();
    virtual ~SignalConnectionItf();
};


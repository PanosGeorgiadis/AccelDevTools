// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include <cstdint>
#include "google_test/google_testing.h"
#include "cpplibs/concurrency/state_machine.h"

namespace cpp
{
namespace concurrency
{
namespace test
{

using namespace ::testing;

enum class State
{
	Connecting,
	Synchronizing,
	Connected,
	Disconnected,
	Reconnecting,
	Stopped,
	Error,
	ConnectingFailed
};

enum class Event
{
	connect,
	connected,
	abort,
	aborted,
	ping
};

class TestStateMachine :
	public Test
{
public:
	TestStateMachine() = default;
	virtual ~TestStateMachine() = default;

protected:
	concurrency::Dispatcher2& dispatcher()
	{
		return m_dispatcher;
	}
private:
	concurrency::Dispatcher2 m_dispatcher;
};


using StateMachine_t = StateMachine<State, Event>;


TEST_F(TestStateMachine, construction)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
}

TEST_F(TestStateMachine, addtransition)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);

	auto connect = []
	{
		std::wcout << "connecting";
	};

	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting, connect);
}

TEST_F(TestStateMachine, addtransition_after_start_throws)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);

	statemachine.start();

	ASSERT_THROW(
		statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting),
		not_allowed_error
	);
}

TEST_F(TestStateMachine, same_entry_throws)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_entry(State::Disconnected, [] {});
	ASSERT_THROW(statemachine.add_entry(State::Disconnected, [] {}), not_unique);
}

TEST_F(TestStateMachine, processevent)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);

	std::uint32_t count(0u);

	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting, [&count] {++count; });
	statemachine.start();
	statemachine.process(Event::connect);

	ASSERT_EQ(1u, count);                                 // verify call has been made
	ASSERT_EQ(State::Connecting, statemachine.state());     // verify end state
}

TEST_F(TestStateMachine, process_event_after_stopped_does_nothing)
{
	std::uint32_t count(0);

	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::ping, State::Stopped, [&count] { count++; });
	statemachine.start();
	statemachine.process(Event::ping);
	ASSERT_EQ(1u, count);
	statemachine.process(Event::ping);
	ASSERT_EQ(1u, count);
}

TEST_F(TestStateMachine, state_enter)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	std::uint32_t count(0);
	statemachine.add_entry(State::Disconnected, [&count] { count++; });
	statemachine.start();
	ASSERT_EQ(1u, count);
}

TEST_F(TestStateMachine, state_leave)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting);

	std::uint32_t count(0);
	statemachine.add_exit(State::Disconnected, [&count] { count++; });
	statemachine.start();
	statemachine.process(Event::connect);
	ASSERT_EQ(1u, count);
}

TEST_F(TestStateMachine, instate_reaction)
{
	std::uint32_t enter_count(0);
	std::uint32_t reaction_count(0);
	std::uint32_t exit_count(0);

	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_reaction(State::Disconnected, Event::ping, [&reaction_count] {reaction_count++; });

	statemachine.add_entry(State::Disconnected, [&enter_count] { enter_count++; });
	statemachine.add_exit(State::Disconnected, [&exit_count] { exit_count++; });
	statemachine.start();
	statemachine.process(Event::ping);

	ASSERT_EQ(1u, enter_count);
	ASSERT_EQ(1u, reaction_count);
	ASSERT_EQ(0u, exit_count);
}

TEST_F(TestStateMachine, transition_reaction)
{
	std::uint32_t enter_count(0);
	std::uint32_t reaction_count(0);
	std::uint32_t exit_count(0);

	auto on_enter_state = [&enter_count] { enter_count++; };
	auto on_exit_state = [&exit_count] { exit_count++; };
	auto action = [&reaction_count] { reaction_count++; };

	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting, action);

	statemachine.add_entry(State::Disconnected, on_enter_state);
	statemachine.add_exit(State::Disconnected, on_exit_state);
	statemachine.add_entry(State::Connecting, on_enter_state);
	statemachine.add_exit(State::Connecting, on_exit_state);

	statemachine.start();
	statemachine.process(Event::connect);

	ASSERT_EQ(2u, enter_count);
	ASSERT_EQ(1u, reaction_count);
	ASSERT_EQ(1u, exit_count);
	ASSERT_EQ(State::Connecting, statemachine.state());
}

TEST_F(TestStateMachine, processevent_without_start_throws)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting);
	ASSERT_THROW(statemachine.process(Event::connect), not_allowed_error);
}

TEST_F(TestStateMachine, doing_state)
{
	StateMachine_t statemachine(dispatcher(), State::Connecting, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting);
	statemachine.add_transition(State::Connecting, Event::connected, State::Connected);

	std::uint32_t count(0u);
	std::uint32_t count_to(10u);

	// make connecting a doing state, activity will be started on its own thread
	// and post back completion signal to state engine
	statemachine.add_activity(State::Connecting, Event::connected, [&count, &count_to]
	{
		for (std::uint32_t i = 0u; i < count_to; i++)
		{
			count++;
		}
	});

	statemachine.start();
	auto ok = statemachine.try_wait_for_state(State::Connected, std::chrono::milliseconds(500));
	ASSERT_TRUE(ok);
	ASSERT_EQ(count_to, count);
	ASSERT_EQ(State::Connected, statemachine.state());
}

TEST_F(TestStateMachine, doing_state_abortion)
{
	std::uint32_t count(0u);
	std::uint32_t count_to(10u);
	std::atomic<bool> abort(false);

	StateMachine_t statemachine(dispatcher(), State::Connecting, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting);
	statemachine.add_transition(State::Connecting, Event::connected, State::Connected);
	statemachine.add_transition(State::Connecting, Event::aborted, State::Disconnected);

	statemachine.add_reaction(State::Connecting, Event::abort, [&abort]()
	{
		abort = true;
	});

	statemachine.add_activity(State::Connecting, Event::connected, Event::aborted, [&count, &count_to, &abort]
	{
		for (std::uint32_t i = 0u; i < count_to; i++)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
			if (abort)
			{
				throw aborted_exception();
			}
			count++;
		}
	});

	statemachine.start();
	statemachine.process(Event::abort);

	auto ok = statemachine.try_wait_for_state(State::Disconnected, std::chrono::milliseconds(500));

	ASSERT_TRUE(ok);
	ASSERT_EQ(State::Disconnected, statemachine.state());
}

TEST_F(TestStateMachine, exception_on_transition_enters_error)
{
	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped, State::Error);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting, []() {throw std::runtime_error("oops"); });

	statemachine.start();

	ASSERT_THROW(statemachine.process(Event::connect), std::runtime_error);
	ASSERT_EQ(State::Error, statemachine.state());
}

TEST_F(TestStateMachine, exception_on_transition)
{
	auto action_with_error = []() {throw std::runtime_error("oops"); };

	StateMachine_t statemachine(dispatcher(), State::Disconnected, State::Stopped);
	statemachine.add_transition(State::Disconnected, Event::connect, State::Connecting, State::ConnectingFailed, action_with_error);

	statemachine.start();
	ASSERT_THROW(statemachine.process(Event::connect), std::runtime_error);
	ASSERT_EQ(State::ConnectingFailed, statemachine.state());
}
}
}
}

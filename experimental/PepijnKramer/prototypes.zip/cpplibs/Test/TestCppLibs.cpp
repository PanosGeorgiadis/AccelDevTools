// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include "google_test/google_testing.h"

int main(int argc, wchar_t* argv[])
{
    ::testing::InitGoogleTest(&argc, argv);
    //gtest_add_tests();
    return RUN_ALL_TESTS();
}


// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include <array>

// Workaround atl include bug
struct IUnknown;
#include <windows.h>

#include <Fei/string_cast.h>
#include <cpplibs/windows/winapierror.h>

namespace cpp
{
namespace windows
{

//---------------------------------------------------------------------------------------------------------------------

winapi_error::winapi_error(const std::string& message) :
    std::runtime_error(message)
{
}

//---------------------------------------------------------------------------------------------------------------------

checked_winapi_error::checked_winapi_error(BOOL retval)
{
    check(retval);
}

void checked_winapi_error::operator=(const BOOL retval)
{
    check(retval);
}

void checked_winapi_error::throw_error()
{
    checked_winapi_error err(FALSE);
}

std::string checked_winapi_error::format_message() const noexcept
try
{
    auto error = ::GetLastError();

    auto flags = static_cast<DWORD>(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS);
    auto lang = static_cast<DWORD>(MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT));
    std::array<wchar_t, 2048> buffer;

    ::FormatMessage(flags, nullptr, error, lang, buffer.data(), static_cast<DWORD>(buffer.size()), nullptr);

    auto str = std::wstring(std::begin(buffer), std::end(buffer));
    return std::move(Fei::string_cast<std::string>(str));
}
catch (const std::exception&)
{
    return std::move(std::string());
}

void checked_winapi_error::check(BOOL retval)
{
    if (retval != TRUE)
    {
        auto message = format_message();
        throw winapi_error(message);
    }
}

}
}
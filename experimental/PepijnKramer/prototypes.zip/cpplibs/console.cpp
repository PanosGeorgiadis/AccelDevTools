// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of ThermoFisher Scientific

#include <iostream>

// Workaround atl include bug
struct IUnknown;
#include <Windows.h>

#include <consoleapi.h>
#include <wincon.h>

#include <cpplibs/windows/winapierror.h>
#include <cpplibs/windows/console.h>

namespace Fei = cpp;

namespace cpp
{
namespace windows
{

Console::Console() :
    m_console(::GetStdHandle(STD_OUTPUT_HANDLE)),
    m_scolormap
{
    {colors::normal,L"\033[0;0m"},
    {colors::black,L"\033[0;30m"},
    {colors::darkGray,L"\033[1;30m"},
    {colors::blue,L"\033[0;34m" },
    {colors::lightBlue,L"\033[1;34m"},
    {colors::green,L"\033[0;32m"},
    {colors::lightGreen, L"\033[1;32m"},
    {colors::cyan,L"\033[0;36m"},
    {colors::lightCyan,L"\033[1;36m"},
    {colors::red,L"\033[0;31m"},
    {colors::lightRed, L"\033[1;31m"},
    {colors::purple, L"\033[0;35m"},
    {colors::lightPurple,L"\033[1;35m"},
    {colors::brown,L"\033[0;033m"},
    {colors::yellow,L"\033[1;033m"},
    {colors::lightGray,L"\033[0;37m"},
    {colors::white, L"\033[1;37m"},
},
m_icolormap
{
    {colors::normal,0x0000},
    {colors::black,0x0000},
    {colors::darkGray, FOREGROUND_INTENSITY },
    {colors::blue, FOREGROUND_BLUE },
    {colors::lightBlue, FOREGROUND_BLUE | FOREGROUND_INTENSITY },
    {colors::green, FOREGROUND_GREEN },
    {colors::lightGreen, FOREGROUND_GREEN | FOREGROUND_INTENSITY },
    {colors::cyan, FOREGROUND_GREEN | FOREGROUND_BLUE },
    {colors::lightCyan, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY },
    {colors::red, FOREGROUND_RED },
    {colors::lightRed, FOREGROUND_RED | FOREGROUND_INTENSITY },
    {colors::purple, FOREGROUND_RED | FOREGROUND_BLUE },
    {colors::lightPurple,FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY },
    {colors::brown, FOREGROUND_RED | FOREGROUND_GREEN },
    {colors::yellow, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY },
    {colors::lightGray, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE },
    {colors::white, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY }
}
{
    if ( m_console == INVALID_HANDLE_VALUE)
    {
        checked_winapi_error::throw_error();
    }
}

std::uint16_t Console::get_attributes() const
{
    CONSOLE_SCREEN_BUFFER_INFO info;
    std::memset(&info, sizeof(info), 0);
    checked_winapi_error error = ::GetConsoleScreenBufferInfo(m_console, &info);
    return info.wAttributes;
}


void Console::set_color(const colors& color)
{
    checked_winapi_error error = ::SetConsoleTextAttribute(m_console, static_cast<WORD>(m_icolormap[color]));
}

void Console::store_color()
{
    m_attributes = get_attributes();
}

void Console::reset_color()
{
    checked_winapi_error error = ::SetConsoleTextAttribute(m_console, m_attributes);
}

void Console::out(const colors& color, const std::wstring& output)
{
    store_color();
    set_color(color);
    std::wcout << box() << output << std::endl;
    reset_color();
}

}
}
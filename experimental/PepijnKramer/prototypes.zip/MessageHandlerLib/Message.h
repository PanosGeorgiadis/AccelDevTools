// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

#include <cstdint>
#include <string>
#include <cpplibs/time/time_types.h>
#include <MessageHandlerLib/interfaces/MessageItf.h>

namespace MessageHandlerLib {

class Message : public MessageItf
{
public:
    Message() = delete;
    Message(const Message&) = delete;
    Message& operator=(const Message&) = delete;
    Message(const MessageType type, const std::wstring& text, const std::wstring& subsystem);
    Message(const MessageType type, const std::wstring& text, const std::wstring& subsystem, const duration_t& timeout);
    //virtual ~Message() override = default;

    // From MessageItf
    virtual const std::uint32_t get_id() const override;
    virtual const MessageType& get_type() const override;
    virtual const std::wstring& get_text() const override;
    virtual const std::wstring& get_subsystem_name() const override;
    virtual const timepoint_t& get_timeout_time() const override;


    // For internal administration
    const bool has_timeout() const;
    //const bool operator<(const Message& other) const;
    const timepoint_t& get_creation_time() const;
    const duration_t& get_timeout_duration() const;
   


private:
    static std::uint32_t s_id;
    const MessageType m_type;
    const std::uint32_t m_msgId;
    const std::wstring m_text;
    const std::wstring m_subsystem;
    const timepoint_t m_creationTime;
    const duration_t m_timeout;
    const timepoint_t m_timeoutTime;
    const bool m_has_timeout;
};

} // namespace MessageHandlerLib
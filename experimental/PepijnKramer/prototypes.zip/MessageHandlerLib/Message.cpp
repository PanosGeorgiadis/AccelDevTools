// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include "Message.h"

namespace MessageHandlerLib {

std::uint32_t Message::s_id = 1;

Message::Message(const MessageType type, const std::wstring& text, const std::wstring& subsystem) :
    m_type(type),
    m_msgId(s_id++),
    m_text(text),
    m_subsystem(subsystem),
    m_creationTime(systemclock_t::now()),
    m_timeout(duration_t::max()),
    m_has_timeout(false)
{
}

Message::Message(const MessageType type, const std::wstring& text, const std::wstring& subsystem, const duration_t& timeout) :
    m_type(type),
    m_msgId(s_id++),
    m_text(text),
    m_subsystem(subsystem),
    m_creationTime(systemclock_t::now()),
    m_timeout(timeout),
    m_timeoutTime(m_creationTime + m_timeout),
    m_has_timeout(true)
{
}

const std::uint32_t Message::get_id() const 
{
    return m_msgId;
}

const MessageType& Message::get_type() const
{
    return m_type;
}

const std::wstring& Message::get_text() const
{
    return m_text;
}

const std::wstring& Message::get_subsystem_name() const
{
    return m_subsystem;
}

const bool Message::has_timeout() const
{
    return m_has_timeout;
}


const timepoint_t& Message::get_creation_time() const
{
    return m_creationTime;
}

const duration_t& Message::get_timeout_duration() const
{
    return m_timeout;
}

const timepoint_t& Message::get_timeout_time() const 
{
    return m_timeoutTime;
}

//const bool Message::operator<(const Message& other) const
//{
//    return m_creationTime < other.m_creationTime;
//}

} // namespace MessageHandlerLib
// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#pragma once

#include <cstdint>
#include <string>
#include <mutex>

#include <cpplibs/concurrency/dispatcher2.h>
#include <cpplibs/events/signal_connection.h>

#include <MessageHandlerLib/interfaces/messagehandleritf.h>
#include "Message.h"

namespace MessageHandlerLib
{

class MessageHandler : public MessageHandlerItf
{
public:
    MessageHandler(const cpp::concurrency::Dispatcher2& dispatcher, const std::wstring& name, const std::uint32_t maxNumberOfMessagesPerType);
    virtual ~MessageHandler();

    //  MessageHandlerItf
    virtual MessageItf& create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem) override;
    virtual MessageItf& create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem, const duration_t& timeout_duration) override;

    virtual const std::wstring& get_name() const override;
    virtual void start(const duration_t& loop_time) override;

    virtual cpp::events::EventConnectionItf& connect_on_message_added(const std::function<MessageEventHandler>& handler) override;
    virtual cpp::events::EventConnectionItf& connect_on_message_removed(const std::function<MessageEventHandler>& handler) override;

    // functions accessible from tests
    const std::uint32_t GetMaxNumberOfMessagesPerType() const;
    const std::uint32_t get_number_of_messages_of_type(const MessageType type) const;
    const std::uint32_t get_total_number_of_messages() const;
    const bool exists(const uint32_t id) const;
    void revoke_all();
    void update();

protected:
    MessageHandler() = default;

private:
    MessageItf& add_message(std::unique_ptr<Message>& message);

    const std::uint32_t m_max_number_of_messages_per_type;
    const cpp::concurrency::Dispatcher2& m_dispatcher;
    const std::wstring m_name;

    std::list<std::unique_ptr<Message>> m_messages;
    cpp::events::SignalConnection<MessageEventHandler> m_message_added_signal;
    cpp::events::SignalConnection<MessageEventHandler> m_message_removed_signal;
};

}
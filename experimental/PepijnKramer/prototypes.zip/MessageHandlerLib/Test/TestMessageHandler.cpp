// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include "google_test/google_testing.h"
#include <cpplibs/concurrency/state_variable.h>
#include <cpplibs/windows/console.h>
#include <MessageHandlerLib/MessageHandlerLib.h>
#include "..\MessageHandler.h"

namespace MessageHandlerLib {
namespace Test {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// TestFixture

using namespace ::testing;

class TestMessageHandler : public Test
{
public:
    const std::uint32_t m_max_number_of_messages_per_type = 100u;

    TestMessageHandler() :
        m_message_handler(m_dispatcher, L"TestHandler", 10u)
    {
    }

protected:

    MessageItf& CreateTestMessage(const MessageType& type, const std::wstring& msg, const std::wstring& subsystem) //TICS -INT#006 false positive
    {
        auto& msg_ref = m_dispatcher.Call([this, &type, &msg, &subsystem]() -> MessageItf&
        {
            return m_message_handler.create_message(type, msg, subsystem);
        });

        return msg_ref;
    }

    MessageItf& CreateTestMessage(const MessageType& type, const std::wstring& msg, const std::wstring& subsystem, const duration_t& timeout_duration) //TICS -INT#006 false positive
    {
        auto& msg_ref = m_dispatcher.Call([this, &type, &msg, &subsystem, &timeout_duration]() -> MessageItf&
        {
            return m_message_handler.create_message(type, msg, subsystem, timeout_duration);
        });

        return msg_ref;
    }

    MessageItf& CreateTestMessage()
    {
        return CreateTestMessage(MessageType::Informational, L"test message", L"TestMessageHandler");
    }

    cpp::windows::Console& console() { return m_console; }
    cpp::concurrency::Dispatcher2& dispatcher() { return m_dispatcher; }
    MessageHandler& message_handler() { return m_message_handler; }

private:
    cpp::windows::Console m_console;
    cpp::concurrency::Dispatcher2 m_dispatcher;
    MessageHandler m_message_handler;

};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tests

TEST_F(TestMessageHandler, Creation)
{
    cpp::concurrency::Dispatcher2 dispatcher(__FUNCTION__);
    MessageHandler message_handler(dispatcher, __FUNCTIONW__, m_max_number_of_messages_per_type);
    ASSERT_EQ(m_max_number_of_messages_per_type, message_handler.GetMaxNumberOfMessagesPerType());
    ASSERT_EQ(__FUNCTIONW__, message_handler.get_name());
}

TEST_F(TestMessageHandler, create_message)
{
    std::uint32_t eventHandledCount(0u);
    cpp::concurrency::Dispatcher2 dispatcher(__FUNCTION__);
    MessageHandler message_handler(dispatcher, __FUNCTIONW__, m_max_number_of_messages_per_type);

    message_handler.connect_on_message_added([this, &dispatcher, &eventHandledCount](const MessageItf& msg)
    {
        dispatcher.CheckIsDispatcherThread("OnMessageAdded");
        console().out(cpp::windows::colors::lightGray, L"Message added received");
        console().out(cpp::windows::colors::lightGray, msg.get_text());
        eventHandledCount++;
    });

    dispatcher.Call([this, &message_handler]() -> MessageItf&
    {
        auto type = MessageType::Informational;
        auto text = std::wstring(L"test message");
        auto subsystem = std::wstring(L"TestMessageHandler");
        return message_handler.create_message(type, text, subsystem);
    });


    dispatcher.Synchronize();   
    ASSERT_EQ(1u, eventHandledCount);
}

TEST_F(TestMessageHandler, create_messageFromWrongThreadThrows)
{
    ASSERT_THROW(
        message_handler().create_message(MessageType::Informational, L"test message", L"TestMessageHandler"),
        cpp::concurrency::not_dispatcher_thread_exception
    );
    dispatcher().Synchronize();
}

TEST_F(TestMessageHandler, TestMaxNumberPerType)
{
    auto& msg1 = CreateTestMessage(MessageType::Informational, L"first message", L"test");
    auto id = msg1.get_id();
    auto maximum = message_handler().GetMaxNumberOfMessagesPerType();
    std::uint32_t   eventHandledCount(0u);

    message_handler().connect_on_message_removed([this, &eventHandledCount](const MessageItf& msg)
    {
        dispatcher().CheckIsDispatcherThread("OnMessageRemoved");
        console().out(cpp::windows::colors::lightGray, L"Message removed received");
        console().out(cpp::windows::colors::lightGray, msg.get_text());
        eventHandledCount++;
    });

    ASSERT_TRUE(message_handler().exists(id));
    ASSERT_EQ(1u, message_handler().get_number_of_messages_of_type(MessageType::Informational));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::Warning));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::Error));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::CriticalError));

    for (auto i = 0u; i < maximum; i++)
    {
        CreateTestMessage(MessageType::Informational, L"info message", L"test");
    }

    ASSERT_FALSE(message_handler().exists(id));
    ASSERT_EQ(maximum, message_handler().get_number_of_messages_of_type(MessageType::Informational));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::Warning));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::Error));
    ASSERT_EQ(0u, message_handler().get_number_of_messages_of_type(MessageType::CriticalError));

    message_handler().revoke_all();
    dispatcher().Synchronize();
}

TEST_F(TestMessageHandler, TestMessageWithTimeout)
{
    const duration_t short_timeout_duration(std::chrono::milliseconds(50));
    const duration_t long_timeout_duration(std::chrono::milliseconds(500));

    CreateTestMessage(MessageType::Informational, L"short timeout message", L"test", short_timeout_duration);
    CreateTestMessage(MessageType::Informational, L"long timeout message", L"test", long_timeout_duration);

    ASSERT_EQ(2u, message_handler().get_total_number_of_messages());

    message_handler().connect_on_message_removed([this](const MessageItf& msg)
    {
        dispatcher().CheckIsDispatcherThread("OnMessageRemoved");
        console().out(cpp::windows::colors::lightGray, L"Message removed received");
        console().out(cpp::windows::colors::lightGray, msg.get_text());
    });

    dispatcher().Call([this]()
    {
        message_handler().update();
    });

    ASSERT_EQ(2u, message_handler().get_total_number_of_messages());
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    dispatcher().Call([this]()
    {
        message_handler().update();
    });

    ASSERT_EQ(1u, message_handler().get_total_number_of_messages());

    dispatcher().Synchronize();
}

TEST_F(TestMessageHandler, NoEventsAfterDisconnectFromEvent)
{
    std::uint32_t eventHandledCount(0u);
    cpp::concurrency::Dispatcher2 dispatcher(__FUNCTION__);
    MessageHandler message_handler(dispatcher, __FUNCTIONW__, m_max_number_of_messages_per_type);

    auto& event_connection = message_handler.connect_on_message_added([this, &dispatcher, &eventHandledCount](const MessageItf& msg)
    {
        dispatcher.CheckIsDispatcherThread("OnMessageAdded");
        console().out(cpp::windows::colors::lightGray, L"Message added received");
        console().out(cpp::windows::colors::lightGray, msg.get_text());
        eventHandledCount++;
    });

    dispatcher.Call([this, &message_handler]() -> MessageItf&
    {
        auto type = MessageType::Informational;
        auto text = std::wstring(L"test message 1");
        auto subsystem = std::wstring(L"TestMessageHandler");
        return message_handler.create_message(type, text, subsystem);
    });

    event_connection.disconnect();

    dispatcher.Call([this, &message_handler]() -> MessageItf&
    {
        auto type = MessageType::Informational;
        auto text = std::wstring(L"test message 2");
        auto subsystem = std::wstring(L"TestMessageHandler");
        return message_handler.create_message(type, text, subsystem);
    });


    dispatcher.Synchronize();
    ASSERT_EQ(1u, eventHandledCount);
}

TEST_F(TestMessageHandler, ActivityStart)
{
    enum class ThreadState
    {
        Idle,
        Running,
        Stopping,
        Stopped
    };

    cpp::concurrency::state_variable<ThreadState> state(ThreadState::Idle);

    // Delegate work
    auto future = std::async([&state]()
    {
        // simulate slow scheduling.
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        std::wcout << L"Hello world!" << std::endl;
        state = ThreadState::Running;

        // do some work.
        for ( auto i = 0; i < 10; i++)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (state==ThreadState::Stopping) break;
        };

        state = ThreadState::Stopped;
    });

    // Wait for work to start
    state.wait_for(ThreadState::Running);
}


} // namespace Test 
} // namespace MeessageHandlerLib
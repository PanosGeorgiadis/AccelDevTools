// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include "google_test/google_testing.h"
#include <MessageHandlerLib/MessageHandlerLib.h>
#include "..\Message.h"

namespace MessageHandlerLib {
namespace Test {

class TestMessage : public ::testing::Test
{
protected:
    std::unique_ptr<Message> CreateDefaultMessage()
    {
        auto type = MessageType::Informational;
        auto text = std::wstring(L"test message");
        auto subsystem = std::wstring(L"test");
        auto msg = std::make_unique<Message>(type, text, subsystem);
        return msg;
    }
};

TEST_F(TestMessage, DefaultConstructor)
{
    auto type = MessageType::Informational;
    auto text = std::wstring(L"test message");
    auto subsystem = std::wstring(L"TestMessage");
    auto msg = std::make_unique<Message>(type, text, subsystem);

    ASSERT_LE(1u, msg->get_id());
    ASSERT_EQ(duration_t::max(), msg->get_timeout_duration());
    ASSERT_EQ(type, msg->get_type());
    ASSERT_EQ(text, msg->get_text());
    ASSERT_EQ(subsystem, msg->get_subsystem_name());
}

TEST_F(TestMessage, TimeoutConstructor)
{
    auto type = MessageType::Informational;
    auto text = std::wstring(L"test message");
    auto subsystem = std::wstring(L"subsystem");
    auto timeout = duration_t(std::chrono::milliseconds(5000));
    auto msg = std::make_unique<Message>(type, text, subsystem, timeout);
    auto expected_timeouttime = msg->get_creation_time() + timeout;

    ASSERT_LE(1u, msg->get_id());
    ASSERT_EQ(type, msg->get_type());
    ASSERT_EQ(text, msg->get_text());
    ASSERT_EQ(subsystem, msg->get_subsystem_name());
    ASSERT_EQ(timeout, msg->get_timeout_duration());
    ASSERT_EQ(expected_timeouttime, msg->get_timeout_time());
}

TEST_F(TestMessage, CreationTime)
{
    auto start = systemclock_t::now();
    auto msg = CreateDefaultMessage();
    auto creation_time = msg->get_creation_time();
    auto end = systemclock_t::now();

    ASSERT_TRUE(creation_time >= start);
    ASSERT_TRUE(creation_time <= end);
}

TEST_F(TestMessage, UniqueIDs)
{
    auto msg1 = CreateDefaultMessage();
    auto msg2 = CreateDefaultMessage();
    auto msg3 = CreateDefaultMessage();
    
    ASSERT_NE(msg1->get_id(), msg2->get_id());
    ASSERT_NE(msg2->get_id(), msg3->get_id());
    ASSERT_NE(msg1->get_id(), msg3->get_id());
}




} // namespace Test
} // namespace MessageHandlerLib
// Copyright (c) 2019 by Thermo Fisher Scientific
// All rights reserved. This file includes confidential and proprietary information of Thermo Fisher Scientific

#include <algorithm>
#include <cpplibs/exceptions/not_implemented.h>
#include "MessageHandler.h"

namespace MessageHandlerLib
{

MessageHandler::MessageHandler(const cpp::concurrency::Dispatcher2& dispatcher, const std::wstring& name, const std::uint32_t maxNumberOfMessagesPerType) :
    m_max_number_of_messages_per_type(maxNumberOfMessagesPerType),
    m_dispatcher(dispatcher),
    m_name(name),
    m_message_added_signal(dispatcher),
    m_message_removed_signal(dispatcher)
{
}

MessageHandler::~MessageHandler()
{

}

const std::wstring& MessageHandler::get_name() const
{
    return m_name;
}


const std::uint32_t MessageHandler::GetMaxNumberOfMessagesPerType() const
{
    return m_max_number_of_messages_per_type;
}

const std::uint32_t MessageHandler::get_number_of_messages_of_type(const MessageType type) const
{
    auto number = m_dispatcher.Invoke([this, &type]()
    {
        return std::count_if(m_messages.begin(), m_messages.end(), [type](const auto& msg)
        {
            return (msg->get_type() == type);
        });
    });

    return static_cast<std::uint32_t>(number);
}

MessageItf& MessageHandler::create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem, const duration_t& timeout_duration)
{
    m_dispatcher.CheckIsDispatcherThread(__FUNCTION__);
    auto msg = std::make_unique<Message>(type, text, subsystem, timeout_duration);
    return add_message(msg);
}

MessageItf& MessageHandler::create_message(const MessageType type, const std::wstring& text, const std::wstring& subsystem)
{
    m_dispatcher.CheckIsDispatcherThread(__FUNCTION__);
    auto msg = std::make_unique<Message>(type, text, subsystem);
    return add_message(msg);
}

MessageItf& MessageHandler::add_message(std::unique_ptr<Message>& message)
{
    m_dispatcher.CheckIsDispatcherThread(__FUNCTION__);
    auto message_type = message->get_type();
    auto& msg_ref = *message.get();

    m_messages.emplace_back(std::move(message));

    //-------------------------------------------------------------------------
    // Do NOT use message anymore it is a nullptr from here on 

    m_message_added_signal.signal(msg_ref);
    std::unique_ptr<Message> removed_msg_ptr;

    if (get_number_of_messages_of_type(message_type) > m_max_number_of_messages_per_type)
    {
        auto it = std::find_if(m_messages.begin(), m_messages.end(), [&message_type](const std::unique_ptr<Message>& msg)
        {
            return msg->get_type() == message_type;
        });


        if (it != m_messages.end())
        {
            // take ownership of message so it can be used in signal to client
            removed_msg_ptr = std::move(*it);
            m_messages.erase(it);
        }
    }

    if (removed_msg_ptr != nullptr)
    {
        m_message_removed_signal.signal(*removed_msg_ptr);
    }

    return msg_ref;
}


cpp::events::EventConnectionItf& MessageHandler::connect_on_message_added(const std::function<MessageEventHandler>& handler)
{
    return m_message_added_signal.connect(handler);
}

cpp::events::EventConnectionItf& MessageHandler::connect_on_message_removed(const std::function<MessageEventHandler>& handler)
{
    return m_message_removed_signal.connect(handler);
}


void MessageHandler::revoke_all()
{
    m_message_added_signal.disconnect();
    m_message_removed_signal.disconnect();
}

const bool MessageHandler::exists(const uint32_t id) const
{
    return m_dispatcher.Invoke([this, id]
    {
        auto it = std::find_if(m_messages.begin(), m_messages.end(), [id](const std::unique_ptr<Message>& msg)
        {
            return msg->get_id() == id;
        });

        return (it != m_messages.end());
    });
}

const std::uint32_t MessageHandler::get_total_number_of_messages() const
{
    auto number = m_dispatcher.Invoke([this]()
    {
        return m_messages.size();
    });

    return static_cast<std::uint32_t>(number);
}

void MessageHandler::start(const duration_t& loop_time)
{
    m_dispatcher.CheckIsNotDispatcherThread(__FUNCTION__);

    m_dispatcher.CallEvery(loop_time, [this]
    {
        update();
    });

}

void MessageHandler::update()
{
    m_dispatcher.CheckIsDispatcherThread(__FUNCTION__);


    std::list<std::unique_ptr<Message>> removed_messages_list;

    if (m_messages.size() > 0)
    {
        auto now = std::chrono::system_clock::now();

        for (auto& msg_ptr : m_messages)
        {
            //std::unique_ptr<Message>& msg_ptr = (*it);
            if (msg_ptr->has_timeout() && (msg_ptr->get_timeout_time() < now))
            {
                removed_messages_list.emplace_back(std::move(msg_ptr));
            }
        }

        m_messages.remove_if([](const std::unique_ptr<Message>& msg_ptr)
        {
            return (msg_ptr == nullptr);
        });

        for (auto& message_ptr : removed_messages_list)
        {
            m_message_removed_signal.signal(*message_ptr);
        }
    }
}

}